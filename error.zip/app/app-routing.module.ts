import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LandingComponent } from './component/landing/landing.component';
import { LoginComponent } from './component/login/login.component';
import { SignupComponent } from './component/signup/signup.component';
import { HomeComponent } from './component/home/home.component';
import { RouterModule ,Routes } from '@angular/router';
import { DetailsComponent } from './component/details/details.component';
import { placeOrderComponent } from './component/placeorder/placeorder.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';




const routes: Routes = [
  {path:'',pathMatch:'full',component:LandingComponent},
  {path:'login',component:LoginComponent},
  {path:'signup',component:SignupComponent},
  {path:'home',component:HomeComponent},
  {path:'details',component:DetailsComponent},
  {path:'placeorder',component:placeOrderComponent}

]
@NgModule({
  declarations: [],
  imports: [
    CommonModule,RouterModule.forRoot(routes), FormsModule, ReactiveFormsModule
  ],
  exports:[RouterModule]
})
export class AppRoutingModule { }
