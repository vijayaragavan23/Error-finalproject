import { Component, OnInit } from "@angular/core";
import { Student } from "src/app/model/student";
import { AuthenticationService } from "src/app/services/authentication.service";
import { DataService } from "src/app/shared/data.service";

@Component({
    selector:'app-placeorder',
    templateUrl: '/placeorder.html'
})
export class placeOrderComponent implements OnInit{
    

    studentsList: Student[] = [];
    studentObj: Student = {
        id: '',
        first_name: '',
        last_name: '',
        email: '',
        mobile: ''
      };
    id: any = '';
    first_name: any = '';
    last_name: any = '';
    email: any = '';
    mobile: any = '';

    constructor(private auth: AuthenticationService, private data : DataService ){ }
    
    ngOnInit(): void {
        this.getAllStudents();
    }

    getAllStudents() {

        this.data.getAllStudents().subscribe(res => {
    
          this.studentsList = res.map((e: any) => {
            const data = e.payload.doc.data();
            data.id = e.payload.doc.id;
            return data;
          })
    
        }, err => {
          alert('Error while fetching student data');
        })
    
      }
     
      addStudent() {
        if (this.first_name == '' || this.last_name == '' || this.mobile == '' || this.email == '') {
          alert('Fill all input fields');
          return;
        }
    
        this.studentObj.id = '';
        this.studentObj.email = this.email;
        this.studentObj.first_name = this.first_name;
        this.studentObj.last_name = this.last_name;
        this.studentObj.mobile = this.mobile;
    
        this.data.addStudent(this.studentObj);
        this.resetForm();
    
      }
    
      updateStudent() {
    
      }
      resetForm() {
        this.id = '';
        this.first_name = '';
        this.last_name = '';
        this.email = '';
        this.mobile = '';
      }



      deleteStudent(student: Student) {
        if (window.confirm('Are you sure you want to delete ' + student.first_name + ' ' + student.last_name + ' ?')) {
          this.data.deleteStudent(student);
        }
      }
    


    

}